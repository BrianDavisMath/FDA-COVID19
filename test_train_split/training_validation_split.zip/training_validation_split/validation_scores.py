import numpy as np
from sklearn.neighbors import NearestNeighbors


def get_validation_weights(training_features_active, training_features_inactive,
                           validation_features_active, validation_features_inactive):
    active_nbrs = NearestNeighbors(n_neighbors=1).fit(training_features_active)
    inactive_nbrs = NearestNeighbors(n_neighbors=1).fit(training_features_inactive)
    act_act_distances, _ = active_nbrs.kneighbors(validation_features_active)
    inact_act_distances, _ = active_nbrs.kneighbors(validation_features_inactive)
    act_inact_distances, _ = inactive_nbrs.kneighbors(validation_features_active)
    inact_inact_distances, _ = inactive_nbrs.kneighbors(validation_features_inactive)
    active_scores = act_act_distances / act_inact_distances
    active_weights = (1 + np.argsort(np.argsort(active_scores.flatten()))) / len(active_scores)
    inactive_scores = inact_inact_distances / inact_act_distances
    inactive_weights = (1 + np.argsort(np.argsort(inactive_scores.flatten()))) / len(inactive_scores)
    return active_weights, inactive_weights



training_features_active = np.random.sample((4,2))
training_features_inactive = np.random.sample((4,2))
validation_features_active = np.random.sample((4,2))
validation_features_inactive = np.random.sample((4,2))

active_weights, inactive_weights = get_validation_weights(training_features_active, training_features_inactive,
                           validation_features_active, validation_features_inactive)
